const axios = require('axios');

const BASE_URL = 'https://jsonplaceholder.typicode.com';

exports.getAllPosts = async () => {
  const res = await axios.get(`${BASE_URL}/posts`);
  return res.data;
};

exports.getPostById = async (id) => {
  const res = await axios.get(`${BASE_URL}/posts/${id}`);
  return res.data;
};

exports.getCommentsByPostId = async (postId) => {
  const res = await axios.get(`${BASE_URL}/comments`, {
    params: { postId }
  });
  return res.data;
};

exports.createPost = async (data) => {
  const res = await axios.post(`${BASE_URL}/posts`, data);
  return res.data;
};

exports.updatePost = async (id, data) => {
  const res = await axios.put(`${BASE_URL}/posts/${id}`, data);
  return res.data;
};

exports.deletePost = async (id) => {
  await axios.delete(`${BASE_URL}/posts/${id}`);
};
