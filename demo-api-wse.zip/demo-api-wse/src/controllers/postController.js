const service = require('../services/jsonPlaceholderService');

exports.getAllPosts = async (req, res) => {
  try {
    const data = await service.getAllPosts();
    res.json(data);
  } catch {
    res.status(500).json({ message: 'Error GET posts' });
  }
};

exports.getPostById = async (req, res) => {
  try {
    const data = await service.getPostById(req.params.id);
    res.json(data);
  } catch {
    res.status(500).json({ message: 'Error GET post by id' });
  }
};

exports.getCommentsByPostId = async (req, res) => {
  try {
    const data = await service.getCommentsByPostId(req.query.postId);
    res.json(data);
  } catch {
    res.status(500).json({ message: 'Error GET comments' });
  }
};

exports.createPost = async (req, res) => {
  try {
    const data = await service.createPost(req.body);
    res.json(data);
  } catch {
    res.status(500).json({ message: 'Error POST data' });
  }
};

exports.updatePost = async (req, res) => {
  try {
    const data = await service.updatePost(req.params.id, req.body);
    res.json(data);
  } catch {
    res.status(500).json({ message: 'Error PUT data' });
  }
};

exports.deletePost = async (req, res) => {
  try {
    await service.deletePost(req.params.id);
    res.json({ message: 'Data berhasil dihapus' });
  } catch {
    res.status(500).json({ message: 'Error DELETE data' });
  }
};
